package ProgramaPizzaria;

public class Main {

	public static void main(String[] args) {
		filaPedidos restaurante = new filaPedidos();
		restaurante.iniciar();

	}

}
