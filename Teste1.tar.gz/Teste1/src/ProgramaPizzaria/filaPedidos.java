package ProgramaPizzaria;

import java.util.*;

public class filaPedidos {
 /* Menu
  * 1-Consultar lista de contatos
  * 2-Inserir contato na lista de contatos
  * 3-Remover contato da lista de contatos
  * 4-Inserir pedido na fila 
  * 5-Remover pedido da fila
  * 6-Organizar as entregas
  * 7-Desempilhar pedido
  * 8-Sair
  */
	private ArrayList<String> listaContatos = new ArrayList<>();
	private Queue<String> filaClientes = new LinkedList<>();
	private Stack<Integer> pilhaEntregas = new Stack<>();
	private Stack<Integer> pilhaEntregasOrg = new Stack<>();
	private Scanner entrada = new Scanner(System.in);
	private Scanner entradaInt = new Scanner(System.in);
	
	private String mostrarMenu() {
		StringBuilder sb = new StringBuilder();
		sb.append("Bem vindo ao Restô. Digite a opção desejada: \n");
		sb.append("1-Consultar lista de contatos\n");
		sb.append("2-Inserir contato na lista de contatos\n");
		sb.append("3-Remover contato da lista de contatos\n");
		sb.append("4-Inserir pedido na fila \n");
		sb.append("5-Remover pedido da fila\n");
		sb.append("6-Adicionar as entregas\n");
		sb.append("7 - Organizar  as entregas\n");
		sb.append("8-Desempilhar pedido\n");
		sb.append("9-Sair");
		System.out.println(sb.toString());
		return entrada.nextLine();
		}
	
	public void iniciar() {
		String opcao = mostrarMenu();
		while (!opcao.equals("9")) {
			switch (opcao) { 
			case "1":
				System.out.println(listaContatos);
				opcao = mostrarMenu();
				break;
				
			case "2":
				System.out.println("Digite o nome do contato:");
				String novo = entrada.nextLine();
				listaContatos.add(novo);
				System.out.println(listaContatos);
				opcao = mostrarMenu();
				break;
				
			case "3":
				System.out.println("Digite o índice do contato a ser apagado: ");
				int indiceRemover = entradaInt.nextInt();
				listaContatos.remove(indiceRemover);
				System.out.println(listaContatos);
				opcao = mostrarMenu();				
				break;
				
			case "4":
				System.out.println("Insira o nome do cliente a ser atendido: ");
				String pedido = entrada.nextLine();
				filaClientes.add(pedido);
				System.out.println(filaClientes);
				opcao = mostrarMenu();	
				break;
				
			case "5":
				System.out.println("Próximo a ser atendido: " + filaClientes.remove());
				System.out.println(filaClientes);
				opcao = mostrarMenu();
				break;
				
			case "6":
				System.out.println("Digite a km da proxima entrega:");
				int entrega = entradaInt.nextInt();
				pilhaEntregas.add(entrega);
				System.out.println(pilhaEntregas);
				opcao = mostrarMenu();
				break;
			
			case "7":
				/*int posicao = 0;
				for (int i = 0; i < pilhaEntregas.size(); i++) {
					if (pilhaEntregas.get(i) > posicao){
						posicao = pilhaEntregas.get(i);
						pilhaEntregasOrg.push(posicao);
					}						
				}
				System.out.println(pilhaEntregasOrg);*/
				while(!pilhaEntregas.isEmpty()) 
		        { 
		            int tmp = pilhaEntregas.pop(); 
		          
		            while(!pilhaEntregasOrg.isEmpty() && pilhaEntregasOrg.peek()  
		                                                 < tmp) 
		            { 
		            	pilhaEntregas.push(pilhaEntregasOrg.pop()); 
		            } 
		            pilhaEntregasOrg.push(tmp); 
		        } 
				System.out.println(pilhaEntregasOrg);
		     	opcao = mostrarMenu();
				break;
				
			
			
			default:
				System.out.println("Opção inválida");
				opcao = mostrarMenu();
			}
		}
		System.out.println("Até mais!");
		
	}
}
