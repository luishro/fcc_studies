package jogo;

import java.util.*;

public class jogoVelha {
	private Scanner ent = new Scanner(System.in);
	private ArrayList<ArrayList<String>> matriz  = new ArrayList<ArrayList<String>>();
	private void imprimeMatriz() {
		for (int i = 0; i < matriz.size(); i++) {
			System.out.println(matriz.get(i));
		}
	}
	private String solicitarJogada() {
		imprimeMatriz();
		return ent.nextLine();
	}
	
	
	
	public void iniciar() {
		ArrayList<String> linha1M = new ArrayList<String>(Arrays.asList("_", "_", "_"));
		ArrayList<String> linha2M = new ArrayList<String>(Arrays.asList("_", "_", "_"));
		ArrayList<String> linha3M = new ArrayList<String>(Arrays.asList("_", "_", "_"));
		
		matriz.add(linha1M);
		matriz.add(linha2M);
		matriz.add(linha3M);
		
		Boolean houveVencedor = false;		
		Boolean vezJogador1 = true;
		for (int i = 0; i < 9; i++) {
			String jogada = solicitarJogada();
			
			// quebrar a jogada para a matriz
			Integer linha  = Integer.valueOf(jogada.split("-")[0]);
			Integer coluna  = Integer.valueOf(jogada.split("-")[1]);
			
			if (!matriz.get(linha).get(coluna).equals("_")) {
				System.out.println("Escolha outra casa!");
				solicitarJogada();
			} else {
				if (vezJogador1) {
					matriz.get(linha).set(coluna, "X");
				
				} else {
					matriz.get(linha).set(coluna, "O");
				}
			}
			
			if (verificar()) {
				houveVencedor = true;
				String vencedor = vezJogador1 ? "1" : "2";
				System.out.println("O jogador " + vencedor + "venceu!");
				break;
				
			}
			vezJogador1 = !vezJogador1;
		}
		if (!houveVencedor) {
			imprimeMatriz();
			System.out.println("Não houve vencedor");
		}
	}
		private Boolean verificar() {
			for (int i = 0; i < 3; i++) {
				//vitoria na horizontal
				String horizontal1 = matriz.get(i).get(0);
				String horizontal2 = matriz.get(i).get(1);
				String horizontal3 = matriz.get(i).get(2);
				
				if (!horizontal1.equals("_")
						&& horizontal1.equals(horizontal2)
						&& horizontal1.equals(horizontal3)) {
					return true;
				}
				
				//verificar na vertical
				String vertical1 = matriz.get(0).get(i);
				String vertical2 = matriz.get(1).get(i);
				String vertical3 = matriz.get(2).get(i);
				if (!vertical1.equals("_")
						&& vertical1.equals(vertical2)
						&& vertical1.equals(vertical3)) {
					return true;
				}
			}
			String diagonal1 = matriz.get(0).get(0);
			String diagonal2 = matriz.get(1).get(1);
			String diagonal3 = matriz.get(2).get(2);
			if (!diagonal1.equals("_") && diagonal1.equals(diagonal2)
					&& diagonal1.equals(diagonal3)) {
				return true;
			}
			String diagonalInv1 = matriz.get(0).get(2);
			String diagonalInv2 = matriz.get(1).get(1);
			String diagonalInv3 = matriz.get(2).get(0);
			if (!diagonalInv1.equals("_") && diagonalInv1.equals(diagonalInv2)
					&& diagonalInv1.equals(diagonalInv3)) {
				return true;
			}			
			
			return false;
		}
		
	}
